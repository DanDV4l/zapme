import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zapme/modules/Home/home.dart';

void main() {
  SharedPreferences.getInstance();
  runApp(MaterialApp(
      title: 'ZapMe', debugShowCheckedModeBanner: false, home: Home()));
}
