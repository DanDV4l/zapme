import 'package:flutter/material.dart';

TextEditingController number = TextEditingController();

List<String> history = [];
List<String> favorites = [];
