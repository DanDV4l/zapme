import 'package:shared_preferences/shared_preferences.dart';
import 'package:zapme/shared/data/variables.dart';

class DataStore {
  void setPrefs() async {
    SharedPreferences cache = await SharedPreferences.getInstance();
    cache.setStringList('history', history);
  }

  void getPrefs() async {
    SharedPreferences cache = await SharedPreferences.getInstance();
    history = await cache.getStringList('history')!;
  }

  void clearPrefs() async {
    SharedPreferences cache = await SharedPreferences.getInstance();
    history.removeLast();
    cache.remove('history');
  }
}
