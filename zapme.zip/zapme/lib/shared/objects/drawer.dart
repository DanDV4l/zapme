import 'package:flutter/material.dart';
import 'package:zapme/shared/data/variables.dart';
import 'package:zapme/shared/objects/buttons.dart';

Widget buildDrawer(context) {
  return Container(
    margin: EdgeInsets.all(15),
    width: 200,
    height: 290,
    decoration: BoxDecoration(
        color: Colors.white.withOpacity(1),
        borderRadius: BorderRadius.all(Radius.circular(20))),
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        buildMenuButton(
            icon: Icons.history,
            label: "Histórico",
            function: () {
              print(history);
            }),
        buildMenuButton(icon: Icons.save_alt_outlined, label: "Números salvos"),
        buildMenuButton(icon: Icons.settings, label: "Ajustes"),
        buildMenuButton(icon: Icons.help_center_outlined, label: "Ajuda"),
        buildMenuButton(icon: Icons.person, label: "Sobre")
      ],
    ),
  );
}
