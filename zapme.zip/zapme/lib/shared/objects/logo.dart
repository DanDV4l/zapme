import 'package:flutter/material.dart';

Widget buildLogo() {
  return Container(
    width: 100,
    height: 100,
    child: Stack(
      children: [
        Icon(
          Icons.contact_phone_rounded,
          size: 100,
          color: Colors.grey.shade900,
        ),
        Positioned(
            right: -20,
            bottom: 18,
            child: Image.asset(
              'assets/images/whatsapp.gif',
              width: 65,
              height: 65,
            ))
      ],
    ),
  );
}
