import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget buildMainButton({label, function}) {
  return InkWell(
    child: Container(
      decoration: BoxDecoration(
          color: Colors.white,
          //border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.all(Radius.circular(15)),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.shade400,
                blurRadius: 2,
                spreadRadius: 0.5,
                offset: Offset(1, 1))
          ]),
      height: 40,
      width: 100,
      child: Center(
          child: Text(
        label,
        textAlign: TextAlign.center,
        style: TextStyle(fontWeight: FontWeight.w500),
      )),
    ),
    onTap: function,
  );
}

Widget buildMenuButton({icon, label, function}) {
  return InkWell(
    onTap: function,
    child: Container(
      margin: EdgeInsets.all(15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Icon(
            icon,
          ),
          VerticalDivider(),
          Text(
            label,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    ),
  );
}
