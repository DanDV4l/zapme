import 'package:flutter/material.dart';
import 'package:zapme/shared/data/datacontrol.dart';
import 'package:zapme/shared/data/variables.dart';
import 'package:zapme/shared/objects/buttons.dart';
import 'package:zapme/shared/objects/drawer.dart';
import 'package:zapme/shared/objects/logo.dart';
import 'package:zapme/shared/objects/textfield.dart';
import 'package:url_launcher/url_launcher.dart';

//import 'dart:html' as html;

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    DataStore dataStore = DataStore();
    dataStore.getPrefs();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: Colors.grey.shade50,
        drawer: buildDrawer(context),
        drawerEnableOpenDragGesture: false,
        drawerScrimColor: Colors.black.withOpacity(0.5),
        body: Container(
          padding: EdgeInsets.all(15),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/images/background.jpg'),
                  fit: BoxFit.cover)),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 20),
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.5),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(8)),
                        color: Colors.grey.shade100.withOpacity(0.8)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            IconButton(
                                onPressed: () =>
                                    _scaffoldKey.currentState?.openDrawer(),
                                icon: Icon(
                                  Icons.menu,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                        buildLogo(),
                        Container(
                          width: 200,
                          height: 1,
                          color: Colors.grey.shade400.withOpacity(0),
                          margin: EdgeInsets.only(top: 15),
                        ),
                        Text(
                          "Digite o número do telefone que deseja chamar no whatsapp.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              // fontWeight: FontWeight.w100,
                              fontSize: 18,
                              color: Colors.black),
                        ),
                        Container(
                          width: 200,
                          height: 1,
                          color: Colors.grey.shade400,
                          margin: EdgeInsets.only(top: 15),
                        ),
                        buildTextField(number),
                        buildMainButton(
                            label: "CHAMAR",
                            function: () async {
                              history.add(number.text);
                              DataStore _dataStore = DataStore();
                              _dataStore.setPrefs();
                              String url = 'https://wa.me/55${number.text}';
                              if (!await launch(url))
                                throw 'Não foi possível abrir $url';

                              number.clear();
                            }),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
