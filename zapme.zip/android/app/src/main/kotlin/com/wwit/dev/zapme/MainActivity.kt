package com.wwit.dev.zapme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
