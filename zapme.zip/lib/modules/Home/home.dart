import 'package:flutter/material.dart';
import 'package:zapme/shared/objects/buttons.dart';
import 'package:zapme/shared/objects/textfield.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:google_fonts/google_fonts.dart';

//import 'dart:html' as html;
TextEditingController number = TextEditingController();

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        body: Container(
          padding: EdgeInsets.all(15),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/images/background.jpg'),
                  fit: BoxFit.cover)),
          child: Center(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 20),
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.5),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(8)),
                        color: Colors.grey.shade100.withOpacity(0.8)),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            IconButton(
                                onPressed: () {},
                                icon: Icon(
                                  Icons.menu,
                                  color: Colors.black,
                                )),
                          ],
                        ),
                        ClipRRect(
                          borderRadius: BorderRadius.all(Radius.circular(15)),
                          child: Image.asset(
                            'assets/images/whatsapp.gif',
                            height: 100,
                            width: 100,
                          ),
                        ),
                        Container(
                          width: 200,
                          height: 1,
                          color: Colors.grey.shade400.withOpacity(0),
                          margin: EdgeInsets.only(top: 15),
                        ),
                        Text(
                          "Para chamar um usuário do WhatsApp sem que o salve em seus contatos, insira abaixo o número do telefone que deseja chamar e depois clique em \"CHAMAR\".",
                          textAlign: TextAlign.justify,
                          style: GoogleFonts.yanoneKaffeesatz(
                              // fontWeight: FontWeight.w100,
                              fontSize: 18,
                              color: Colors.black),
                        ),
                        Container(
                          width: 200,
                          height: 1,
                          color: Colors.grey.shade400,
                          margin: EdgeInsets.only(top: 15),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('+55',
                                style: GoogleFonts.yanoneKaffeesatz(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                    color: Colors.black)),
                            buildTextField(number),
                          ],
                        ),
                        buildMainButton(
                            label: "CHAMAR",
                            function: () async {
                              String url = 'https://wa.me/55${number.text}';
                              if (!await launch(url))
                                throw 'Could not launch $url';
                            }),
                      ],
                    ),
                  ),
                  Text(
                    "Desenvolvido por:\nDanDV4l\nWw:IT",
                    style: GoogleFonts.ptMono(),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
