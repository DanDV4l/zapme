import 'package:flutter/material.dart';
import 'package:zapme/modules/Home/home.dart';

void main() => runApp(MaterialApp(
    title: 'ZapMe', debugShowCheckedModeBanner: false, home: Home()));
