import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

Widget buildTextField(controller) {
  return Container(
    margin: EdgeInsets.all(15),
    child: Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 200,
          height: 40,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(30)),
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.shade400,
                    blurRadius: 2,
                    spreadRadius: 0.5,
                    offset: Offset(2, 1))
              ]),
        ),
        SizedBox(
          width: 200,
          height: 55,
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.phone,
            style: GoogleFonts.inconsolata(fontSize: 20),
            textAlign: TextAlign.center,
            maxLength: 11,
            cursorColor: Colors.grey.withOpacity(0.1),
            cursorHeight: 20,
            textAlignVertical: TextAlignVertical.center,
            decoration: InputDecoration(
              fillColor: Colors.white,
              filled: true,
              labelText: "DDD + Telefone",
              labelStyle: GoogleFonts.yanoneKaffeesatz(
                  color: Colors.grey,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
              counter: Offstage(),
              focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.all(Radius.circular(30))),
              border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.all(Radius.circular(30))),
              enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.all(Radius.circular(30))),
            ),
          ),
        )
      ],
    ),
  );
}
